<?php
/**
 * Class Co2okTest
 *
 * @package Co2ok_Plugin
 */

/**
 * Co2ok test case.
 */
class Co2okTest extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	function test_co2ok() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}
}
